package getset;

public class variables {
    private static String cnpj;
    private static String nome_empresa;
    private static String objetivo_neg;
    private static String entregavel_min;
    private static String entregaveis_possi;
    private static String solucao;
    private static String produto;
    private static String funcionalidade;
    private static String core;

        Object[] novoProduto = new Object[]{
            cnpj,
            nome_empresa,
        };

    public Object[] getNovoProduto() {
        return novoProduto;
    }    
    
    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNome_empresa() {
        return nome_empresa;
    }

    public void setNome_empresa(String nome_empresa) {
        this.nome_empresa = nome_empresa;
    }

    public String getObjetivo_neg() {
        return objetivo_neg;
    }

    public void setObjetivo_neg(String objetivo_neg) {
        this.objetivo_neg = objetivo_neg;
    }

    public String getEntregavel_min() {
        return entregavel_min;
    }

    public void setEntregavel_min(String entregavel_min) {
        this.entregavel_min = entregavel_min;
    }
     public String getEntregaveis_possi() {
        return entregaveis_possi;
    }

    public void setEntregaveis_possi(String entregaveis_possi) {
        this.entregaveis_possi = entregaveis_possi;
    }
     public String getSolucao() {
        return solucao;
    }
    public void setSolucao(String solucao) {
        this.solucao = solucao;
     }
     public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }
    public String getFuncionalidade() {
        return funcionalidade;
    }

    public void setFuncionalidade(String funcionalidade) {
        this.funcionalidade = funcionalidade;
    }
    public String getCore() {
        return core;
    }
    public void setCore(String core) {
        this.core = core;       
    }
}
    
